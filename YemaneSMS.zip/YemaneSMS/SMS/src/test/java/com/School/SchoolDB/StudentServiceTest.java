package com.School.SchoolDB;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import jpa.entitymodels.Student;
import jpa.service.StudentService;

public class StudentServiceTest {

	
	private static StudentService StudentService;
	
	@Test
	public void testGetStudentByEmail() {
		StudentService = new StudentService();
		Student expectedStudent = new Student();
		expectedStudent.setId(11);
		expectedStudent.setName("Emily Johnson");
		expectedStudent.setEmail("Emily@gmail.com");
		Student actual = StudentService.getStudentByEmail("Emily@gmail.com");
		System.out.println(actual.getName());
		assertEquals(expectedStudent.getName(), actual.getName());
		
	}
	
	
}
