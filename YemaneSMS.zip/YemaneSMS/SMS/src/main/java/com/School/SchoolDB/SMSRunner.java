package com.School.SchoolDB;

import org.hibernate.Session;
import org.hibernate.Transaction;

import jpa.HConnection.HConnect;
import jpa.dao.CourseDAO;
import jpa.dao.StudentDAO;
import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import jpa.service.CourseService;
import jpa.service.StudentProgram;
import jpa.service.StudentService;
import java.util.Set;
import java.util.HashSet;
import java.util.Scanner;
/**
 * Hello world!
 *
 */
//Driver class, run application from here
public class SMSRunner {
	
	static Session session = HConnect.getConnect();
	static Transaction tx = session.beginTransaction();	
	
	static StudentProgram spObj = new StudentProgram();
	
	

	
    public static void main( String[] args ) {
        
    	
    	spObj.appMenu();

    }		
	}

