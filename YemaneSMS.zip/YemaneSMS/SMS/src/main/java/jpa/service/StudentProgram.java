package jpa.service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Scanner;

import jpa.HConnection.HConnect;
import jpa.dao.StudentDAO;
import java.util.Set;
import jpa.entitymodels.Course;

//provides first options for User upon application startup, and method to find specic student's courses
public class StudentProgram {

	static Scanner input = new Scanner(System.in);
	static StudentDAO sObj = new StudentService();
	Set<Course> studentCourses = new HashSet<Course>();  
	
	public void appMenu() {
		System.out.println("Are you a(n): \n \n1. Student \n \n2. Quit \n Please enter 1 or 2.");
		int firstChoice = input.nextInt();
		if (firstChoice == 1) {
			sObj.validateStudent();
		} else if (firstChoice == 2) {
			System.out.println("Good bye!");
			System.exit(0);
		}
		
	}
	
	public Set<Course> currentStudentCourses(String email) {
		String sqlQuery = "SELECT C.CID, C.NAME, C.INSTRUCTOR FROM COURSE C "
				+ "JOIN Student_course SC ON C.CID = SC.COURSELIST_CID "
				+ "JOIN STUDENT S ON SC.STUDENT_ID = S.ID"
				+ " WHERE S.EMAIL = ?";
		try {
		Connection conn;
		try {
			conn = HConnect.sqlConnect();
			PreparedStatement ps = conn.prepareStatement(sqlQuery);
			ps.setString(1, email);
			ResultSet results = ps.executeQuery();
			
			while (results.next()) {
				int cId = results.getInt("cId");
				String cName = results.getString("name");
				String instructor = results.getString("Instructor");
				
				Course c = new Course();
				c.setcId(cId);
				c.setName(cName);
				c.setInstructor(instructor);
				
				studentCourses.add(c);
			}
			for (Course c : studentCourses) {
				System.out.println("\nCourse ID:" +c.getcId() + " Course Name:" +c.getName() + " Instructor:" +c.getInstructor());
			}
			System.out.println("\nYou have been signed out!");
			System.exit(0);
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}		return null;
		
		
	}
	
}
