package jpa.service;

import java.util.List;


import javax.persistence.TypedQuery;

import org.hibernate.Session;

import jpa.HConnection.HConnect;
import jpa.dao.CourseDAO;
import jpa.entitymodels.Course;

//DAO Implementation/Service layer, concrete implementations for all functions in abstract CourseDAO layer
public class CourseService extends HConnect implements CourseDAO {

	List <Course> allCourses;
	
	
	//Function to return all course information
	@Override
	public List<Course> getAllCourses() {
		
		Session session = HConnect.getConnect();
		
		String hqlQuery = "FROM Course";
		TypedQuery tq = session.createQuery(hqlQuery);
		allCourses = tq.getResultList();
		
		for (Course c : allCourses) {
			System.out.println("\nCourse ID: " +c.getcId() + " Course name: " +c.getName() + " Instructor: " +c.getInstructor());
		}
		
		session.close();
		return allCourses;
	}

	
	
	
}
