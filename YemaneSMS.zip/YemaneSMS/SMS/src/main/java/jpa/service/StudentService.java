package jpa.service;

import java.util.List;

import javax.persistence.TypedQuery;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.hibernate.Session;

import com.School.SchoolDB.SMSRunner;

import java.sql.Connection;
import jpa.HConnection.HConnect;
import jpa.dao.StudentDAO;
import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import java.util.Set;
import java.util.HashSet;
import java.util.Scanner;

//DAO Implementation/Service layer, concrete implementations for all functions in abstract studentDAO layer
public class StudentService extends HConnect implements StudentDAO {

	Set<Course> studentCourses = new HashSet<Course>();
	CourseService csObj = new CourseService();	
	Scanner input = new Scanner(System.in);
	Course cObj = new Course();
	StudentProgram spObj = new StudentProgram();
	private String email;
	private String password;
	Student sObj = new Student();
	
	
	//Function to get all student information
	@Override
	public List<Student> getAllStudents() {
		Session session = HConnect.getConnect();
		
		String hqlQuery = "FROM Student";
		TypedQuery tq = session.createQuery(hqlQuery);
		
		List<Student> allStudents = tq.getResultList();
		
		for (Student s : allStudents) {
			System.out.println("Student ID: " + s.getId() + " Student name: " +s.getName());
		}
		session.close();
		return allStudents;
	}

	//Method to return student information by using their email
	@Override
	public Student getStudentByEmail(String email) {
		Session session = HConnect.getConnect();
		
		String hqlQuery = "FROM Student WHERE email = :email";
		
		TypedQuery tq = session.createQuery(hqlQuery);
		tq.setParameter("email", email);
		
		Student sObj = (Student) tq.getSingleResult();
		
		System.out.println("Student ID: " + sObj.getId() + " Student name: " +sObj.getName());
		
		session.close();
		return sObj;
		
	}

	
	//Method to only let student user access more functions in application with exact correct credentials
	@Override
	public void validateStudent() {
		System.out.println("Please enter your email");
		email = input.next();
		System.out.println("Please enter your password");
		password = input.next();
		
		Session session = HConnect.getConnect();
		String hqlQuery = "FROM Student where email = :email";
		
		TypedQuery tq = session.createQuery(hqlQuery);
		tq.setParameter("email", email);
		Student sObj = (Student) tq.getSingleResult();
		
		String hqlQuery2 = "FROM Student where password = :password";
		
		TypedQuery tq2 = session.createQuery(hqlQuery2);
		tq.setParameter("email", email);
		sObj = (Student) tq.getSingleResult();
		 
		if((sObj.getEmail().equals(email)) && (sObj.getPassword().equals(password))) {
		getStudentCourses(email);
		} else {
			System.out.println("Your credentials are invalid.");
			System.exit(0);
		}
		session.close();
		}

	
	//Method to ask student user if they would like to be registered to a class, then adding that course to their courselist.
	
	@Override
	public void registerStudentToCourse(String email) {
	
		System.out.println("\nWould you like to: \n1.Register a class\n2. Logout\n\nPlease Enter Selection: ");
		
		int selection = input.nextInt();
		
		switch(selection) {
		case 1: 
		List <Course> allCourses = csObj.getAllCourses();
		System.out.println(" \nWhich course would you like to be registered in? Enter the Course ID: ");
		
			int newCourseId = input.nextInt();
			
			
			Session session = HConnect.getConnect();
			String hqlQuery = "SELECT id FROM Student WHERE email = :email";
			TypedQuery tq = session.createQuery(hqlQuery);
			tq.setParameter("email", email);
			
			int sId = (int) tq.getSingleResult();
			sObj.setId(sId);
			
			session.close();
			
			try {
				Connection conn = HConnect.sqlConnect();
				String sqlQuery = "INSERT INTO Student_Course (Student_id, Courselist_cid, student_email) \n"
						+ "VALUES (?, ?, ?)";
				PreparedStatement ps = conn.prepareStatement(sqlQuery);
				ps.setInt(1, sId);
				ps.setInt(2, newCourseId);
				ps.setString(3, email);
				ps.executeUpdate();
				
				spObj.currentStudentCourses(email);
				
				conn.close();
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			break;
		case 2: 
			default:
				System.out.println("Logging out. Goodbye!");
				System.exit(0);
		}
	}

	
	//Method to get course information of student based on student email
	@Override
	public List<Course> getStudentCourses(String email) {
		String sqlQuery = "SELECT C.CID, C.NAME, C.INSTRUCTOR FROM COURSE C "
				+ "JOIN Student_course SC ON C.CID = SC.COURSELIST_CID "
				+ "JOIN STUDENT S ON SC.STUDENT_ID = S.ID"
				+ " WHERE S.EMAIL = ?";
		try {
		Connection conn;
		try {
			conn = HConnect.sqlConnect();
			PreparedStatement ps = conn.prepareStatement(sqlQuery);
			ps.setString(1, email);
			ResultSet results = ps.executeQuery();
			
			while (results.next()) {
				int cId = results.getInt("cId");
				String cName = results.getString("name");
				String instructor = results.getString("Instructor");
				
				Course c = new Course();
				c.setcId(cId);
				c.setName(cName);
				c.setInstructor(instructor);
				
				studentCourses.add(c);
			}
			for (Course c : studentCourses) {
				System.out.println("\nCourse ID:" +c.getcId() + " Course Name:" +c.getName() + " Instructor:" +c.getInstructor());
			}
			registerStudentToCourse(email);
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}		return null;
	}}
