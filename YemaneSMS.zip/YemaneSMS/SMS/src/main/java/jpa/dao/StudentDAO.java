package jpa.dao;

import java.util.List;
import jpa.entitymodels.Student;
import jpa.entitymodels.Course;

//Abstract DAO Layer
public interface StudentDAO {

	List <Student> getAllStudents();
	
	Student getStudentByEmail(String email);
	
	void validateStudent();
	
	void registerStudentToCourse(String email);
	
	List<Course> getStudentCourses(String email);
	
}
