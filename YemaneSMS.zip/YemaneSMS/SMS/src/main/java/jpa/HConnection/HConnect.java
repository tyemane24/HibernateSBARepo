package jpa.HConnection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Provides functions to open connections to database, create sessions to perform CRUD operations on database using SQL&HQL 
public class HConnect {

	public static Session getConnect() {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		return session;
		
	}
	public static Connection sqlConnect() throws SQLException, ClassNotFoundException {
	
		String url =  "jdbc:mysql://localhost:3306/SchoolDB"; 
		 String USER = "root";
		 String PASS = "Password123!";
		Connection conn = DriverManager.getConnection(url, USER, PASS);

		
		return conn;
		
	}
}
