package jpa.entitymodels;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


//Course model/POJO-mapped to Course table in DB

@Entity
@Table
public class Course implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(nullable = false)
	private int cId;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String Instructor;
	
	
	public Course() {}

	public Course(int cId, String name, String instructor) {
		super();
		this.cId = cId;
		this.name = name;
		Instructor = instructor;
	}

	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInstructor() {
		return Instructor;
	}

	public void setInstructor(String instructor) {
		Instructor = instructor;
	}

	@Override
	public String toString() {
		return "Course [cId=" + cId + ", name=" + name + ", Instructor=" + Instructor + "]";
	}
	
	
	
}
