package jpa.entitymodels;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import java.util.Set;

import javax.persistence.*;

//Student model/POJO-mapped to Student table in DB

@Entity
@Table
public class Student implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(nullable = false)
	private int Id;
	
	
	@Column(nullable = false)
	@ColumnDefault("-1")
	private String email;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String password;
	
	@ManyToMany(targetEntity = Course.class)
	private Set<Course> CourseList;
	
	public Student() {}

	public Student(int id, String email, String name, String password, Set<Course> CourseList) {
		super();
		Id = id;
		this.email = email;
		this.name = name;
		this.password = password;
		this.CourseList = CourseList;
	}

	public Set<Course> getCourseList() {
		return CourseList;
	}

	public void setCourseList(Set<Course> courseList) {
		CourseList = courseList;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Student [Id=" + Id + ", email=" + email + ", name=" + name + ", password=" + password + "]";
	}
	
	
	
}
